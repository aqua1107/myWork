module breakoutStyleGame {
	requires java.desktop;
}